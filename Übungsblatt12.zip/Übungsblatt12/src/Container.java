import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Container {
    private List<Event> events = new ArrayList<>();

    public List<Event> sortEventAscending() {
        Collections.sort(events);
        return events;
    }

    public void addEvent(Event event) {
        try {
            events.add(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Event> sortEventDescending() {
        Collections.sort(events);
        Collections.reverse(events);
        return events;
    }

    public void deleteEvents(int position){
        events.remove(position-1);
    }
}
