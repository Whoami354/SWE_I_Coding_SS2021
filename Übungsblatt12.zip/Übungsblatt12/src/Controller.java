
public class Controller {
    private Container container = new Container();
    private UI ui = new UI();

    public void run() {
        ui.printWelcome();
        int option = 0;
        while (option != 1) {
            ui.displayOption();
            option = ui.getInput();
            switch (option) {
                case 1 -> ui.printGoodbye();
                case 2 -> createNewEvent();
                case 3 -> outputSortedEvents();
                case 4 -> deleteDates();
                default -> ui.printError();
            }
        }
    }

    private void createNewEvent() {
        String date = ui.askDate();
        String time = ui.askTime();
        String description = ui.askDescription();
        int duration = ui.askHowLong();
        try {
            container.addEvent(new Event(new MyTime(date, time), description, duration));
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private void outputSortedEvents() {
        int howToSort = ui.askHowToSort();
        switch (howToSort) {
            case 1 -> ui.printEvents(container.sortEventAscending());
            case 2 -> ui.printEvents(container.sortEventDescending());
            default -> System.err.println("Bitte geben Sie eine Zahl zwischen 1 oder 2 ein.");
        }
    }

    private void deleteDates() {
        ui.printEvents(container.sortEventDescending());
        int deleteEvent = ui.askWhatToDelete();
        container.deleteEvents(deleteEvent);
    }
}
