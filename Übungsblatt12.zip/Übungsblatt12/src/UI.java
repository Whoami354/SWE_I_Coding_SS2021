import java.util.List;
import java.util.Scanner;

public class UI {
    Scanner sc = new Scanner(System.in);

    public void displayOption() {
        System.out.println("(1) Programm beenden!" +
                         "\n(2) Termin festlegen" +
                         "\n(3) Termine ausgeben lassen" +
                         "\n(4) Temin(e) löschen");
    }

    public void printGoodbye() {
        System.out.println("Auf Wiedersehen!");
    }

    public void printWelcome() {
        System.out.println("Herzlich Willkommen!" +
                           "\nWas möchten Sie tun?");
    }

    public void printEvents(List<Event> events) {
        int counter = 1;
        if (events.size() == 0) {
            System.out.println("Keine Events vorhanden");
        }
        for (Event event : events) {
            System.out.println(counter++ + ". " + event);
        }
    }

    public String askDate() {
        System.out.println("Bitte geben Sie Ihr Datum ein! (Format: DD.MM.YYYY)");
        return sc.nextLine();
    }

    public String askDescription() {
        System.out.println("Was wollen Sie an diesem Tag machen?");
        return sc.nextLine();
    }

    public String askTime() {
        System.out.println("Bitte geben Sie Ihre Uhzeit ein! (Format: hh:mm)");
        return sc.nextLine();
    }

    public int askHowLong() {
        System.out.println("Wie lange soll das Ereigniss in Minuten dauern! (Höchstens 600 Minuten)");
        return sc.nextInt();
    }

    public int askHowToSort() {
        System.out.println("Wie wollen Sie Ihre Liste sortiert ausgeben lassen?\n" +
                "(1) Aufsteigend\n" +
                "(2) Absteigend");
        return sc.nextInt();
    }

    public int askWhatToDelete() {
        System.out.println("Welcher Temin Soll gelöscht werden? Geben Sie bitte den entsprechenden Index als Zahl an.");
        return sc.nextInt();
    }

    public void printError() {
        System.err.println("Bitte geben Sie einen Wert zwischen 1 und 4 ein.");
    }

    public int getInput() {
        int input = sc.nextInt();
        sc.nextLine();
        return input;
    }
}

